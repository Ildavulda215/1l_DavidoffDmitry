import UIKit

enum windowState
    {
        case open
        case close
    }

enum engineTurn
    {
        case turnOn
        case turnOff
    }

struct SportCar {
    var bodyvolume: Double
    var bodyfilled: Double
    {
        didSet
        {
            if (bodyvolume > bodyfilled)
            {
                let space = bodyvolume - bodyfilled
                print ("\(carmodel) - багажник свободен, осталось свободного пространства: \(space) килограмм.")
            }
            else if (bodyfilled > bodyvolume)
            {
                print("Багажник перегружен.")
            }
            else
            {
                print("Багажник заполнен.")
            }
        }
    }
    let carmodel: String
    let yearmade: Int
    var engine: engineTurn
    {
        willSet
        {
            if newValue == .turnOn
            {
                print ("\(carmodel) - двигатель запущен.")
            }   else {print("\(carmodel) - двигатель заглушен.")}
        }
    }
    var windowState: windowState
    {
        willSet
        {
            if newValue == .open
            {
                print("\(carmodel) - окна открыты.")
            }   else { print("\(carmodel) - окна закрыты.") }
        }
    }
}

struct TrunkCar {
    var bodyvolume: Double
    var bodyfilled: Double
    {
        didSet
        {
            if (bodyvolume > bodyfilled)
            {
                let space = bodyvolume - bodyfilled
                print ("\(carmodel) - багажник свободен, осталось свободного пространства: \(space) килограмм.")
            }
            else if (bodyfilled > bodyvolume)
            {
                print("Багажник перегружен.")
            }
            else
            {
                print("Багажник заполнен.")
            }
        }
    }
    let carmodel: String
    let yearmade: Int
    var engine: engineTurn
    {
        willSet {
            if newValue == .turnOn {
                print ("\(carmodel) - двигатель запущен.")
            } else {print("\(carmodel) - двигатель заглушен.")}
        }
    }
    var windowState: windowState {
        willSet {
            if newValue == .open {
                print("\(carmodel) - окна открыты.")
            } else { print("\(carmodel) - окна закрыты.") }
        }
    }
}

var car = SportCar(bodyvolume: 100.0, bodyfilled: 120.0, carmodel: "Мазда 3", yearmade: 2001, engine: .turnOn, windowState: .close)
var car1 = TrunkCar(bodyvolume: 300.0, bodyfilled: 120.0, carmodel: "Камаз", yearmade: 1997, engine: .turnOff, windowState: .open)

var car2 = SportCar(bodyvolume: 100.0, bodyfilled: 50, carmodel: "Мазда 6", yearmade: 2001, engine: .turnOff, windowState: .open)
var car3 = TrunkCar(bodyvolume: 300.0, bodyfilled: 200.0, carmodel: "Маз", yearmade: 1996, engine: .turnOn, windowState: .close)

car.engine = .turnOff
car1.windowState = .close
car2.engine = .turnOn
car3.windowState = .open

car.bodyfilled = 100
car1.bodyfilled = 100
car2.bodyfilled = 200
car3.bodyfilled = 150

print("Машина марки \(car1.carmodel) выпущена в \(car1.yearmade) году. Объем багажника: \(car1.bodyvolume) килограмм.")

