import UIKit

struct RegistrationUser {
    enum RegistrationUserError: Error {
        case empty
        case toShort(nameLength: Int)
        case toLong(nameLength: Int)
    }

    let name: String

    init(name: String) throws {
        guard !name.isEmpty else {
            throw RegistrationUserError.empty
        }
        guard name.count > 1 else {
            throw RegistrationUserError.toShort(nameLength: name.count)
        }
        guard name.count < 50 else {
            throw RegistrationUserError.toLong(nameLength: name.count)
               }

        self.name = name
    }
}

do {
    let user = try RegistrationUser(name: "")
    print("Пользователь под именем \(user.name) создан.")
} catch {
    print("Создание пользователя привело к ошибке: \(error)")
}

do {
    let user = try RegistrationUser(name: "Дмитрий Давыдов")
    print("Пользователь под именем \(user.name) создан.")
} catch {
    print("Создание пользователя привело к ошибке: \(error)")
}

do {
    let user = try RegistrationUser(name: "ждловарврававдаороаовалдворароврлаорвоаолвраовраловарловралорвлоар")
    print("Пользователь под именем \(user.name) создан.")
} catch {
    print("Создание пользователя привело к ошибке: \(error)")
}

