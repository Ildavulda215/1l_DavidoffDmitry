import UIKit

    enum tonirovka
    {
        case tonHaving
        case tonNotHaving
    }
    enum trunkFull
    {
        case sto
        case nesto
    }
    enum signalisation: String
    {
        case signOn = "включена"
        case signOff = "выключена"
    }
    enum сarDoorState: String
    {
        case open = "двери открыты"
        case close = "двери закрыты"
    }
    enum reg: String
    {
        case have = "в наличие"
        case havent = "отсутствует"
    }

    protocol Car
    {
        var name: String {get}
        var yearMade: Int {get}
        var sign: signalisation {get set}
        var doors: сarDoorState {get set}
        var registration: reg {get set}
        func go() -> Bool
    }

    extension Car
    {
        func changeSignalisationState(sign: signalisation) -> String
           {
            switch (sign)
                {
                    case .signOn:
                        return "Сигнализация включена"
                    case .signOff:
                        return "Сигнализация выключена"
                }
           }
        mutating func changeDoorsState(doors: сarDoorState)
        {
            self.doors = doors
        }
        mutating func changeRegistrationState(registration: reg)
        {
            self.registration = registration
        }
    }
        class trunkCar: Car {
            var trunk: trunkFull
            var name: String
            var yearMade: Int
            var sign: signalisation
            var doors: сarDoorState
            var registration: reg
            
            init(trunk: trunkFull, yearMade: Int, name: String, sign: signalisation, doors: сarDoorState, registration: reg) {
                self.trunk = trunk
                self.name = name
                self.yearMade = yearMade
                self.sign = sign
                self.doors = doors
                self.registration = registration
            }
            
            func go() -> Bool {
                if trunk == .sto {
                    print("Вы можете ехать. Грузовик загружен.")
                    return true
                } else {
                    print("Вы не можете ехать. Грузовик загружается.")
                    return false
                }
            }
        }

        extension trunkCar: CustomStringConvertible{
                   var description: String {
                    return "Статус дверей: \(doors.rawValue). Статус сигнализации: \(sign.rawValue). Статус регистрации: \(registration.rawValue). Дата выпуска автомобиля: \(yearMade)."
                   }
               }

        class  sportCar: Car {
            var window: tonirovka
            var name: String
            var yearMade: Int
            var sign: signalisation
            var doors: сarDoorState
            var registration: reg
            
            init(window: tonirovka, yearMade: Int, name: String, sign: signalisation, doors: сarDoorState, registration: reg) {
                self.window = window
                self.name = name
                self.yearMade = yearMade
                self.sign = sign
                self.doors = doors
                self.registration = registration
            }
            
            func go() -> Bool {
                if window == .tonNotHaving {
                    print("Вы можете ехать.")
                    return true
                } else {
                    print("Вы не можете ехать.")
                    return false
                }
            }
        }

        extension sportCar: CustomStringConvertible{
            var description: String {
                 return "Спортивный автомобиль \(name) был выпущен в \(yearMade) году."
            }
        }

let MAZ = trunkCar(trunk: .sto, yearMade: 2001, name: "MAZ", sign: .signOff, doors: .open, registration: .have)
let KAMAZ = trunkCar(trunk: .nesto, yearMade: 1998, name: "KAMAZ", sign: .signOff, doors: .open, registration: .have)
MAZ.go()
MAZ.doors
KAMAZ.go()
KAMAZ.name
print(MAZ.description)

let Ferrari = sportCar(window: .tonHaving, yearMade: 2018, name: "Ferrari", sign: .signOff, doors: .open, registration: .have)
let Lambоrghini = sportCar(window: .tonNotHaving, yearMade: 2017, name: "Lambоrghini", sign: .signOn, doors: .close, registration: .havent)
Ferrari.go()
Ferrari.sign
Ferrari.name
Ferrari.doors
Lambоrghini.go()
Lambоrghini.sign
Lambоrghini.yearMade
Lambоrghini.registration
print(Ferrari.description)

print(MAZ.changeSignalisationState(sign: .signOff))

