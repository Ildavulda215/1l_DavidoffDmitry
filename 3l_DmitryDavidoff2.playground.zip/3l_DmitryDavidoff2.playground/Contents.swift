import UIKit

enum windowState
    {
        case open
        case close
    }

enum engineTurn
    {
        case turnOn
        case turnOff
    }

struct SportCar {
    var bodyvolume: Double
    var bodyfilled: Double
    {
        didSet
        {
            if (bodyvolume > bodyfilled)
            {
                let space = bodyvolume - bodyfilled
                print ("\(carmodel) - багажник свободен, осталось свободного пространства: \(space) килограмм.")
            }
            else if (bodyfilled > bodyvolume)
            {
                print("Багажник перегружен.")
            }
            else
            {
                print("Багажник заполнен.")
            }
        }
    }
    var carmodel: String
    mutating func changeSeries(ms:String) {
        switch ms {
        case "Mazda 6":
            self.carmodel = "Mazda 6"
        case "Mazda 3":
            self.carmodel = "Mazda 3"
        default:
            print("Легкового автомобиля нет в наличии")
        }
    }
    let yearmade: Int
    var engine: engineTurn
    {
        willSet
        {
            if newValue == .turnOn
            {
                print ("\(carmodel) - двигатель запущен.")
            }   else {print("\(carmodel) - двигатель заглушен.")}
        }
    }
    var windowState: windowState
    {
        willSet
        {
            if newValue == .open
            {
                print("\(carmodel) - окна открыты.")
            }   else { print("\(carmodel) - окна закрыты.") }
        }
    }
}

struct TrunkCar {
    var bodyvolume: Double
    var bodyfilled: Double
    {
        didSet
        {
            if (bodyvolume > bodyfilled)
            {
                let space = bodyvolume - bodyfilled
                print ("\(carmodel) - багажник свободен, осталось свободного пространства: \(space) килограмм.")
            }
            else if (bodyfilled > bodyvolume)
            {
                print("Багажник перегружен.")
            }
            else
            {
                print("Багажник заполнен.")
            }
        }
    }
    var carmodel: String
    mutating func changeSeries(ms:String) {
        switch ms {
        case "KAMAZ":
            self.carmodel = "KAMAZ"
        case "MAZ":
            self.carmodel = "MAZ"
        default:
            print("Грузового автомобиля нет в наличии")
        }
    }
    let yearmade: Int
    var engine: engineTurn
    {
        willSet {
            if newValue == .turnOn {
                print ("\(carmodel) - двигатель запущен.")
            } else {print("\(carmodel) - двигатель заглушен.")}
        }
    }
    var windowState: windowState {
        willSet {
            if newValue == .open {
                print("\(carmodel) - окна открыты.")
            } else { print("\(carmodel) - окна закрыты.") }
        }
    }
}

var car = SportCar(bodyvolume: 100.0, bodyfilled: 120.0, carmodel: "Mazda 3", yearmade: 2001, engine: .turnOn, windowState: .close)
var car1 = TrunkCar(bodyvolume: 300.0, bodyfilled: 120.0, carmodel: "KAMAZ", yearmade: 1997, engine: .turnOff, windowState: .open)

var car2 = SportCar(bodyvolume: 100.0, bodyfilled: 50, carmodel: "Mazda 6", yearmade: 2001, engine: .turnOff, windowState: .open)
var car3 = TrunkCar(bodyvolume: 300.0, bodyfilled: 200.0, carmodel: "MAZ", yearmade: 1996, engine: .turnOn, windowState: .close)

car.engine = .turnOff
car1.windowState = .close
car2.engine = .turnOn
car3.windowState = .open

car.bodyfilled = 100
car1.bodyfilled = 100
car2.bodyfilled = 200
car3.bodyfilled = 150

car2.changeSeries(ms: "MAZ")
car3.changeSeries(ms: "KAMAZ")

print("Машина марки \(car3.carmodel) выпущена в \(car1.yearmade) году. Объем багажника: \(car1.bodyvolume) килограмм.")
print("Машина марки \(car.carmodel) выпущена в \(car.yearmade) году. Объем багажника: \(car.bodyvolume) килограмм.")

