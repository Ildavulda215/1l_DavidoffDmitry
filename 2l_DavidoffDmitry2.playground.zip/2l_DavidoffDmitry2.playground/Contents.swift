import UIKit

// 1. Написать функцию, которая определяет, четное число или нет.
var arrayOfNumbers = [44, 41, 32, 19, 89, 11, 22, 5, 100, 5422]
for divisionOnTwo in arrayOfNumbers
    {
        if divisionOnTwo % 2 == 0
            {
                print("\(divisionOnTwo) четное число.")
            }
        else
            {
                print("\(divisionOnTwo) нечетное число.")
            }
    }

// 2. Написать функцию, которая определяет, делится ли число без остатка на 3.
for divisionOnThree in arrayOfNumbers
    {
        if divisionOnThree % 3 == 0
            {
                print("\(divisionOnThree) делится без остатка.")
            }
        else
            {
                print("\(divisionOnThree) делится с остатком.")
            }
    }

// 3. Создать возрастающий массив из 100 чисел.
var arrayOneHunfred: Array<Int> = []
for i in 1...100
    {
        arrayOneHunfred.append(i)
    }

print(arrayOneHunfred)

// 4. Удалить из этого массива все четные числа и все числа, которые не делятся на 3.
var annihilation = arrayOneHunfred.filter {$0 % 2 != 0 && $0 % 3 == 0}

print(annihilation)

// 5. * Написать функцию, которая добавляет в массив новое число Фибоначчи, и добавить при помощи нее 100 элементов.

func arrayFibonacci(n: Int) -> [Decimal]
    {
        var Fn: [Decimal] = [0, 1]
        (2...n).forEach { i in Fn.append(Fn[i - 1] + Fn[i - 2]) }
        return Fn
    }

print(arrayFibonacci(n: 100))

// 6. * Заполнить массив из 100 элементов различными простыми числами. Натуральное число, большее единицы, называется простым, если оно делится только на себя и на единицу. Для нахождения всех простых чисел не больше заданного числа n, следуя методу Эратосфена, нужно выполнить следующие шаги:
// a. Выписать подряд все целые числа от двух до n (2, 3, 4, ..., n).
// b. Пусть переменная p изначально равна двум — первому простому числу.
// c. Зачеркнуть в списке числа от 2 + p до n, считая шагом p..
// d. Найти первое не зачёркнутое число в списке, большее, чем p, и присвоить значению переменной p это число.
// e. Повторять шаги c и d, пока возможно.

func conditions (number: Int) -> Bool
    {
        if number < 2
            {
                return false
            }
        for i in 2..<number
            {
                if number % i == 0
                    {
                        return false
                    }
            }
        
        return true
    }

func primeNumbers () -> [Int]
    {
        var primeNumbersArray = [Int]()
        var i = 2
        while primeNumbersArray.count < 100
            {
                if conditions(number: i)
                    {
                        primeNumbersArray.append(i)
                    }
                i += 1
            }
        
        return primeNumbersArray
    }
    
print (primeNumbers())

// Второй вариант решения 3 и 4 задач.

var testArray: [Int] = []
for i in 1...100 {
    testArray.append(i)
}

for value in testArray {
    if (value % 2) == 0 {
        testArray.remove(at: testArray.firstIndex(of: value)!)
    }
}

for value in testArray {
    if (value % 3) != 0 {
        testArray.remove(at: testArray.firstIndex(of: value)!)
    }
}

print(testArray)

