import UIKit

// Задача 1. Решение квадратного уравнения типа ax^2+bx+c=0

let a: Double = 5.0
let b: Double = 10.0
let c: Double = 3.0
var r1: Double
var r2: Double

var discriminant = pow(b, 2) - 4 * a * c

if (a == 0)
    {
        r1 = -c/b
        print ("Уравнение принимает вид линейного уравнения bx+c=0 и имеет единственный корень равный \(r1).")
    }

else if (b == 0 && c == 0)
    {
        print ("Уравнение принимает вид ax^2=0 и имеет единственный корень равный нулю.")
    }

else if (b == 0 || c == 0)
    {
        print ("Уравнение является неполным квадратным уравнением.")
    }

else if (discriminant == 0)
    {
        r1 = (-b/(2*a))
        print ("У уравнения один вещественный корень \(r1).")
    }

else if (discriminant > 0)
    {
        r1 = (-b+sqrt(discriminant))/(2*a)
        r2 = (-b-sqrt(discriminant))/(2*a)
        print ("У уравнения два вещественных корня \(r1) и \(r2).")
    }

else
    {
        print ("У уравнения нет вещественных корней, но существуют два комплексных корня.")
    }

// Задача 2. Нахождение площади, периметра и гипотенузы треугольника

let leg1: Float = 5
let leg2: Float = 10

var area = (leg1 * leg2) / 2.0
var hypotenuse = sqrt((pow(leg1, 2)) + (pow(leg2, 2)))
var perimeter = leg1 + leg2 + hypotenuse

print("Площадь треугольника: \(area), периметр треугольника: \(perimeter), гипотенуза треугольника: \(hypotenuse).")

// Задача 3. Сумма вклада через 5 лет.

typealias ruble = Float
typealias percentage = Float
var amountOfDeposit : ruble = 1000.0
var years = 1
let annualPercentage : percentage = 10.0

while years <= 5
    {
        let percentOfRuble = amountOfDeposit / 100.0
        let annualIncome = percentOfRuble * annualPercentage
        amountOfDeposit = amountOfDeposit + annualIncome
        years += 1
    }

print("Сумма вклада через 5 лет: \(amountOfDeposit) рублей.")
