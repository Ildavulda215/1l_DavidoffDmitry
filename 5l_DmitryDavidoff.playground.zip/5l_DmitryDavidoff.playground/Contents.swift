import UIKit

    enum tonirovka
    {
        case tonHaving
        case tonNotHaving
    }
    enum trunkFull
    {
        case sto
        case nesto
    }
enum signalisation
    {
        case signOn
        case signOff
    }
    enum сarDoorState
    {
        case open
        case close
    }
    enum reg
    {
        case have
        case havent
    }

    protocol Car
    {
        var name: String {get}
        var yearMade: Int {get}
        var sign: signalisation {get set}
        var doors: сarDoorState {get set}
        var registration: reg {get set}
        func go() -> Bool
    }

    extension Car
    {
        mutating func changeSignalisationState(sign: signalisation)
        {
            self.sign = sign
        }
        mutating func chageDoorsState(doors: сarDoorState)
        {
            self.doors = doors
        }
        mutating func chageRegistrationState(registration: reg)
        {
            self.registration = registration
        }
    }
        class trunkCar: Car {
            var trunk: trunkFull
            var name: String
            var yearMade: Int
            var sign: signalisation
            var doors: сarDoorState
            var registration: reg
            
            init(trunk: trunkFull, yearMade: Int, name: String, sign: signalisation, doors: сarDoorState, registration: reg) {
                self.trunk = trunk
                self.name = name
                self.yearMade = yearMade
                self.sign = sign
                self.doors = doors
                self.registration = registration
            }
            
            func go() -> Bool {
                if trunk == .sto {
                    print("Вы можете ехать. Грузовик загружен.")
                    return true
                } else {
                    print("Вы не можете ехать. Грузовик загружается.")
                    return false
                }
            }
        }

        extension trunkCar: CustomStringConvertible{
                   var description: String {
                    return "Статус дверей: \(doors). Статус сигнализации: \(sign). Статус регистрации: \(registration). Дата выпуска автомобиля: \(yearMade)."
                   }
               }

        class  sportCar: Car {
            var window: tonirovka
            var name: String
            var yearMade: Int
            var sign: signalisation
            var doors: сarDoorState
            var registration: reg
            
            init(window: tonirovka, yearMade: Int, name: String, sign: signalisation, doors: сarDoorState, registration: reg) {
                self.window = window
                self.name = name
                self.yearMade = yearMade
                self.sign = sign
                self.doors = doors
                self.registration = registration
            }
            
            func go() -> Bool {
                if window == .tonNotHaving {
                    print("Вы можете ехать.")
                    return true
                } else {
                    print("Вы не можете ехать.")
                    return false
                }
            }
        }

        extension sportCar: CustomStringConvertible{
            var description: String {
                 return "Спортивный автомобиль \(name) был выпущен в \(yearMade) году."
            }
        }

let MAZ = trunkCar(trunk: .sto, yearMade: 2001, name: "MAZ", sign: .signOff, doors: .open, registration: .have)
let KAMAZ = trunkCar(trunk: .nesto, yearMade: 1998, name: "KAMAZ", sign: .signOff, doors: .open, registration: .have)
MAZ.go()
MAZ.doors
KAMAZ.go()
KAMAZ.name
print(MAZ.description)

let Ferrari = sportCar(window: .tonHaving, yearMade: 2018, name: "Ferrari", sign: .signOff, doors: .open, registration: .have)
let Lambоrghini = sportCar(window: .tonNotHaving, yearMade: 2017, name: "Lambоrghini", sign: .signOn, doors: .close, registration: .havent)
Ferrari.go()
Ferrari.sign
Ferrari.name
Ferrari.doors
Lambоrghini.go()
Lambоrghini.sign
Lambоrghini.yearMade
Lambоrghini.registration
print(Ferrari.description)

