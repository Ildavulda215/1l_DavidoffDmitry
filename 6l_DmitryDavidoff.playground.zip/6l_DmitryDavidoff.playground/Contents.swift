import UIKit

struct penaltyDataBase {
    var name: String
    var type: String
    var penaltyValue: Int
    
}

extension penaltyDataBase: CustomStringConvertible {
    var description: String {
        return "Водитель \(name), совершил правонарушение: \(type). Размер штрафа: \(penaltyValue)"
    }
    
}


struct Queue <T> {
    private var elements: [T] = []
    
    public var isEmpty: Bool {
        return elements.count == 0
    }
    
    mutating func add(element: T) {
        elements.append(element)
    }
    mutating func remove()->T {
        return elements.removeFirst()
    }
    
    func printQueue() {
        print(elements)
    }
    subscript (index: Int) -> T?
    {
        if index < elements.count && index > 0 {return elements[index]}
        else {return nil}
    }
}

extension Queue {
    func filter(predicate:(T) -> Bool) -> [T] {
        var result = [T]()
        for i in elements {
            if predicate(i) {
                result.append(i)
            }
        }
        return result
    }
}


var bastards = Queue<penaltyDataBase>()
bastards.add(element: .init(name: "Дмитрий Давыдов", type: "нарушение скоростного режима", penaltyValue: 1500))
bastards.add(element: .init(name: "Илья Никишов", type: "езда без ремня безопасности", penaltyValue: 3000))
bastards.add(element: .init(name: "Илья Демидов", type: "нарушение скоростного режима", penaltyValue: 1500))
bastards.add(element: .init(name: "Полина Завьялова", type: "пересечение сплошной полосы", penaltyValue: 1000))
bastards.add(element: .init(name: "Алиса Розенбаум", type: "незаконная парковка", penaltyValue: 2500))
bastards.add(element: .init(name: "Филипп Киркоров", type: "нарушение скоростного режима", penaltyValue: 1500))

print(bastards.remove())
print(bastards.remove())

bastards.printQueue()

let speedBastards = bastards.filter(predicate: {$0.penaltyValue == 1500})
print("Злостные нарушители скорости:", speedBastards)

bastards[7]
bastards[3]
