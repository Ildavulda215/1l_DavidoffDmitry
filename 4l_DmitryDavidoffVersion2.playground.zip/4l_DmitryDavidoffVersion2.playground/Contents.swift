import UIKit

class Car
{
        var name: String
        var yearMade: Int
        var doorState: сarDoorState
        init(name: String, yearMade: Int, doorState: сarDoorState)
        {
            self.name = name
            self.yearMade = yearMade
            self.doorState = doorState
        }
        func registration() {}
        func openDoors() {
        if doorState == .open
        {
            print("Двери машины открыты")
        }
        else
        {
            print("Двери машины закрыты")
        }
    }
}

    enum tonirovka
    {
        case tonHaving
        case tonNotHaving
    }
    enum trunkFull
    {
        case trunkIsFull
        case trunkIsEmpty
    }
    enum signalisation
    {
        case signOn
        case signOff
    }
    enum сarDoorState
    {
        case open
        case close
    }
    enum reg
    {
        case have
        case havent
    }

class trunkCar: Car
    {
        var cargo: trunkFull
        var sign: signalisation
        var regist: reg
    init(name: String, yearMade: Int, cargo: trunkFull, sign: signalisation, regist: reg, doorState: сarDoorState)
        {
            self.cargo = cargo
            self.sign = sign
            self.regist = regist
            super.init(name: name, yearMade: yearMade, doorState: doorState)
        }
        func cargoOfTrunk()
        {
            if cargo == .trunkIsFull
            {
                print("Грузовик заполнен")
            }
            else
            {
                print("Грузовик свободен")
            }
        }
        func signalOnOff()
           {
               if sign == .signOn
               {
                   print("Сигнализация грузовика включена")
               }
               else
               {
                   print("Сигнализация грузовика выключена")
               }
           }
        override func registration()
        {
            if regist == .have
            {
                print("Регистрация номера проведена")
            }
            else
            {
                print("Нет регистрации номера")
            }
        }
    }
class sportCar: Car
    {
        var blackWindows: tonirovka
        var sign: signalisation
        var regist: reg
    init(name: String, yearMade: Int, blackWindows: tonirovka, sign: signalisation, regist: reg, doorState: сarDoorState)
        {
            self.blackWindows = blackWindows
            self.sign = sign
            self.regist = regist
            super.init(name: name, yearMade: yearMade, doorState: doorState)
        }
        func colorOfWindows()
        {
            if blackWindows == .tonHaving
            {
                print("Окна спорткара затонированы")
            }
            else
            {
                print("Окна спорткара не затонированы")
            }
        }
        func signalOnOff()
        {
            if sign == .signOn
            {
                print("Сигнализация спорткара включена")
            }
            else
            {
                print("Сигнализация спорткара выключена")
            }
        }
        override func registration()
        {
            if regist == .have
            {
                print("Регистрация груза проведена")
            }
            else
            {
                print("Нет регистрации груза")
            }
        }
    }

let KAMAZ = trunkCar(name: "KAMAZ", yearMade: 1990, cargo: .trunkIsFull, sign: .signOn, regist: .have, doorState: .close)
KAMAZ.cargoOfTrunk()
KAMAZ.signalOnOff()
KAMAZ.openDoors()
KAMAZ.registration()
let Ferrari = sportCar(name: "Ferrari", yearMade: 2001, blackWindows: .tonHaving, sign: .signOff, regist: .havent, doorState: .open)
Ferrari.colorOfWindows()
Ferrari.signalOnOff()
Ferrari.openDoors()
Ferrari.registration()
